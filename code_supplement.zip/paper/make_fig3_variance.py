import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

dims = [2, 5, 6, 8, 10, 20]
var_r = [0.0004, 0.0013, 0.0011, 0.0012, 0.0022, 0.1226]
c01 = [0.13, 0.22, 0.19, 0.20, 0.27, 1.79]
full_osc = [2.27, 2.91, 2.50, 2.11, 2.27, 54.65]

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4.5))
ax1.semilogy(dims, var_r, 'o-', color='#2266AA', lw=2, ms=8, label='Var$(r)$')
ax1.set_xlabel('Dimension $D$', fontsize=12)
ax1.set_ylabel('Var$(r)$', fontsize=12)
ax1.set_title('(a) Residual variance vs dimension', fontsize=12)
ax1.grid(True, alpha=0.2)
ax1.annotate('Flow capacity\ndegradation', xy=(20, 0.12), xytext=(16, 0.008), fontsize=9, color='#CC4444', arrowprops=dict(arrowstyle='->', color='#CC4444'))

ax2.bar(range(len(dims)), full_osc, width=0.35, label='Full osc', color='#CC4444', alpha=0.7, align='center')
ax2.bar([x+0.35 for x in range(len(dims))], c01, width=0.35, label='$\\hat{C}_{0.01}$ (core osc)', color='#2266AA', alpha=0.7, align='center')
ax2.set_xticks([x+0.175 for x in range(len(dims))])
ax2.set_xticklabels(['$D$='+str(d) for d in dims])
ax2.set_ylabel('Oscillation', fontsize=12)
ax2.set_title('(b) Full oscillation vs core oscillation', fontsize=12)
ax2.legend(fontsize=10)
ax2.set_yscale('log')
ax2.grid(True, alpha=0.2, axis='y')

plt.tight_layout()
plt.savefig('fig3_variance_scaling.png', dpi=200, bbox_inches='tight')
plt.savefig('fig3_variance_scaling.pdf', dpi=300, bbox_inches='tight')
print('Saved fig3_variance_scaling')
