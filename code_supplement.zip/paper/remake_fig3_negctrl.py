"""
Regenerate the negative-control figure (Panel C simplified to acceptance
rate only) directly from saved results, without retraining the flows.

Reads:  ../experiments/results_v2/negative_control_D10.json
Writes: negative_control_D10.png   (in this paper/ directory)
"""

import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

HERE = Path(__file__).resolve().parent
JSON_PATH = HERE / '..' / 'experiments' / 'results_v2' / 'negative_control_D10.json'
D = 10


def make_negative_control_plot(all_results, D, out_dir):
    """Bar chart comparing conditions (Panel C: acceptance rate only)."""
    conds = list(all_results.keys())
    labels = ['Well-trained\n(CerT-OG-Anneal)', 'Under-trained\n(200 ep, NLL only)',
              'Misspecified\n(4 layers, 32 hid)']

    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    fig.suptitle(f'Negative Control: Certificate II Discriminative Power (banana $D={D}$)',
                 fontsize=13)

    x = np.arange(len(conds))
    colors = ['#44AA66', '#DDAA44', '#CC4444']

    # Panel 1: Core gamma at rho=0.01
    gammas_01 = [all_results[c].get('quantiles', {}).get('0.01', {}).get('gamma_core', 0)
                 for c in conds]
    axes[0].bar(x, gammas_01, color=colors)
    axes[0].set_xticks(x)
    axes[0].set_xticklabels(labels, fontsize=9)
    axes[0].set_title(r'Core $\gamma$ ($\rho = 0.01$)', fontsize=11)
    axes[0].set_ylabel(r'$\gamma_{\mathrm{core}}$')
    for i, v in enumerate(gammas_01):
        axes[0].text(i, v + 0.01, f'{v:.3f}', ha='center', fontsize=9)

    # Panel 2: Core gamma at rho=0.05
    gammas_05 = [all_results[c].get('quantiles', {}).get('0.05', {}).get('gamma_core', 0)
                 for c in conds]
    axes[1].bar(x, gammas_05, color=colors)
    axes[1].set_xticks(x)
    axes[1].set_xticklabels(labels, fontsize=9)
    axes[1].set_title(r'Core $\gamma$ ($\rho = 0.05$)', fontsize=11)
    axes[1].set_ylabel(r'$\gamma_{\mathrm{core}}$')
    for i, v in enumerate(gammas_05):
        axes[1].text(i, v + 0.01, f'{v:.3f}', ha='center', fontsize=9)

    # Panel 3: acceptance rate only (simpler, no ambiguity)
    accepts = [all_results[c]['accept_rate'] for c in conds]
    axes[2].bar(x, accepts, color=colors, alpha=0.7)
    axes[2].set_xticks(x)
    axes[2].set_xticklabels(labels, fontsize=9)
    axes[2].set_title('Acceptance rate', fontsize=11)
    axes[2].set_ylabel('Accept rate')
    axes[2].set_ylim(0, 1.1)
    for i, v in enumerate(accepts):
        axes[2].text(i, v + 0.02, f'{v:.3f}', ha='center', fontsize=9)

    plt.tight_layout()
    out_path = out_dir / f'negative_control_D{D}.png'
    plt.savefig(out_path, dpi=150, bbox_inches='tight')
    plt.close()
    print(f"  Plot: {out_path}")


if __name__ == '__main__':
    with open(JSON_PATH) as f:
        all_results = json.load(f)
    make_negative_control_plot(all_results, D, HERE)
