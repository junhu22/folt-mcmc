"""
CerT-MCMC JASA Paper — Hero Figure (Figure 1)
===============================================
Usage:
  python make_hero_figure.py
  python make_hero_figure.py --dpi 300 --format pdf
  python make_hero_figure.py --no-inset

All data hardcoded from experimental results.
Edit DATA section below to update numbers.
"""

import argparse
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from mpl_toolkits.axes_grid1.inset_locator import inset_axes


# ══════════════════════════════════════════════════════════════
# DATA — edit these to update figure
# ══════════════════════════════════════════════════════════════

BANANA = {
    'D':        [2,     5,     6,     8,     10,    20],
    'v1_gamma': [0.152, 0.020, 0.010, 0.011, 0.003, 1e-10],
    'v2_01':    [0.933, 0.890, 0.908, 0.902, 0.865, 0.286],
    'v2_05':    [0.982, 0.950, 0.961, 0.952, 0.935, 0.540],
}

REAL_WORLD = {
    'target': ['Sailboat', 'Shear', 'Heart'],
    'D':      [6, 8, 13],
    'v2_01':  [0.359, 0.430, 0.636],
}

ESS_CALIBRATION = {
    'rho':    [0.005, 0.01, 0.025, 0.05, 0.10, 0.25],
    'proxy':  [0.003, 0.013, 0.044, 0.094, 0.190, 0.340],
    'actual': 0.178,
    'highlight_rho': 0.10,
    'highlight_proxy': 0.190,
}

# Residual simulation parameters for Panel B (banana D=10)
RESIDUAL_SIM = {
    'mean': 0.692,
    'std': 0.047,
    'n_sim': 200000,
    'outlier_frac': 0.005,
    'outlier_shift': 0.5,
    'outlier_scale': 0.3,
    'seed': 42,
}

TAXONOMY = [
    {
        'label': 'Full certificate\nsuccess',
        'status': 'Cert I + II\nnon-vacuous',
        'examples': 'Banana $D=2, 5$',
        'color': '#44AA66',
    },
    {
        'label': 'Core certificate\nsuccess',
        'status': 'Cert II non-vacuous,\nCert I vacuous',
        'examples': 'Banana $D=6$--$10$\nSailboat, Shear',
        'color': '#4488CC',
    },
    {
        'label': 'Transport\ndegradation',
        'status': 'Cert II weaker\n($\\gamma < 0.5$)',
        'examples': 'Banana $D=20$\nLogReg $D=20$',
        'color': '#DDAA44',
    },
    {
        'label': 'Transport\nfailure',
        'status': 'Cert II vacuous',
        'examples': '(Under-trained flow)',
        'color': '#CC4444',
    },
]


# ══════════════════════════════════════════════════════════════
# STYLE
# ══════════════════════════════════════════════════════════════

COLORS = {
    'v1': '#CC4444',
    'v2_01': '#2266AA',
    'v2_05': '#44AA66',
    'actual': '#333333',
    'core_fill': '#4488CC',
    'highlight': '#FF6600',
}

FIGSIZE = (14, 11)
FONT_TITLE = 12
FONT_LABEL = 11
FONT_LEGEND = 8
FONT_ANNOT = 10


# ══════════════════════════════════════════════════════════════
# PANEL FUNCTIONS
# ══════════════════════════════════════════════════════════════

def panel_a_spectral_gap(ax):
    """Panel A: Certified spectral gap vs dimension."""
    c = COLORS
    d = BANANA

    ax.semilogy(d['D'], d['v1_gamma'], 'o-', color=c['v1'], lw=2, ms=7,
                label='Cert I (covering)', zorder=3)
    ax.semilogy(d['D'], d['v2_01'], 's-', color=c['v2_01'], lw=2, ms=7,
                label=r'Cert II ($\rho = 0.01$)', zorder=3)
    ax.semilogy(d['D'], d['v2_05'], '^-', color=c['v2_05'], lw=2, ms=7,
                label=r'Cert II ($\rho = 0.05$)', zorder=3)

    # Real-world targets
    ax.semilogy(REAL_WORLD['D'], REAL_WORLD['v2_01'], 'D',
                color=c['v2_01'], ms=10, markeredgecolor='black',
                markeredgewidth=0.8, zorder=4,
                label='Applied targets')

    ax.set_xlabel('Dimension $D$', fontsize=FONT_LABEL)
    ax.set_ylabel(r'Certified spectral gap $\gamma$', fontsize=FONT_LABEL)
    ax.set_title('(a) Certified spectral gap vs dimension',
                 fontsize=FONT_TITLE, fontweight='bold')
    ax.legend(fontsize=FONT_LEGEND, loc='lower left', ncol=1, framealpha=0.9)
    ax.set_ylim(5e-4, 2)
    ax.set_xlim(0, 22)
    ax.grid(True, alpha=0.2, which='both')

    ax.annotate('Cert I collapses', xy=(10, 0.003), xytext=(13, 0.015),
                fontsize=FONT_ANNOT, color=c['v1'],
                arrowprops=dict(arrowstyle='->', color=c['v1'], lw=1.2))
    ax.annotate('Cert II stable', xy=(10, 0.865), xytext=(15, 1.2),
                fontsize=FONT_ANNOT, color=c['v2_01'],
                arrowprops=dict(arrowstyle='->', color=c['v2_01'], lw=1.2))


def panel_b_residual(ax, show_inset=True):
    """Panel B: Residual distribution with core/tail decomposition."""
    c = COLORS
    p = RESIDUAL_SIM

    np.random.seed(p['seed'])
    n = p['n_sim']
    r_bulk = p['mean'] + p['std'] * np.random.randn(n)
    n_out = int(p['outlier_frac'] * n)
    r_lo = p['mean'] - np.random.exponential(p['outlier_scale'], n_out) - p['outlier_shift']
    r_hi = p['mean'] + np.random.exponential(p['outlier_scale'], n_out) + p['outlier_shift']
    r_sim = np.concatenate([r_bulk[:-2*n_out], r_lo, r_hi])

    q01 = np.quantile(r_sim, 0.01)
    q99 = np.quantile(r_sim, 0.99)
    rmin, rmax = r_sim.min(), r_sim.max()

    bins = np.linspace(rmin - 0.05, rmax + 0.05, 200)
    counts, edges = np.histogram(r_sim, bins=bins, density=True)
    centers = 0.5 * (edges[:-1] + edges[1:])
    core_m = (centers >= q01) & (centers <= q99)
    tail_lo = centers < q01
    tail_hi = centers > q99

    ax.fill_between(centers[core_m], 0, counts[core_m], alpha=0.4,
                    color=c['core_fill'],
                    label=r'Core $\tilde{G}_{0.01}$ (98% proposal mass)')
    ax.plot(centers, counts, '-', color=c['actual'], lw=0.8)
    ax.fill_between(centers[tail_lo], 0, counts[tail_lo], alpha=0.5,
                    color=c['v1'], label='Tail (< 2% mass, drives Cert I)')
    ax.fill_between(centers[tail_hi], 0, counts[tail_hi], alpha=0.5,
                    color=c['v1'])

    ax.axvline(q01, color=c['v2_01'], ls='--', lw=1.2, alpha=0.8)
    ax.axvline(q99, color=c['v2_01'], ls='--', lw=1.2, alpha=0.8)

    # Full-range bracket
    bracket_y = -0.35
    ax.annotate('', xy=(rmin, bracket_y), xytext=(rmax, bracket_y),
                arrowprops=dict(arrowstyle='<->', color=c['v1'], lw=1.5))
    ax.annotate('Full osc = %.1f' % (rmax - rmin),
                xy=((rmin + rmax) / 2, bracket_y),
                xytext=(rmax - 0.5, 1.5),
                fontsize=FONT_ANNOT, color=COLORS['v1'], ha='right',
                arrowprops=dict(arrowstyle='->', color=COLORS['v1'], lw=1))

    # Core range: double-headed bracket between the two dashed quantile lines
    c_rho = q99 - q01
    ax.annotate('', xy=(q01, 6.5), xytext=(q99, 6.5),
                arrowprops=dict(arrowstyle='<->', color=COLORS['v2_01'], lw=1.5))
    ax.text((q01 + q99) / 2, 6.8, '$\\hat{C}_{0.01}$ = %.2f' % c_rho,
            fontsize=FONT_ANNOT, color=COLORS['v2_01'], ha='center')

    # Log-density inset
    if show_inset:
        ax_ins = inset_axes(ax, width="32%", height="30%", loc='right',
                            borderpad=2)
        ax_ins.semilogy(centers, counts + 1e-4, '-', color=c['actual'], lw=0.6)
        ax_ins.fill_between(centers[core_m], 1e-4, counts[core_m] + 1e-4,
                            alpha=0.3, color=c['core_fill'])
        ax_ins.fill_between(centers[tail_lo], 1e-4, counts[tail_lo] + 1e-4,
                            alpha=0.4, color=c['v1'])
        ax_ins.fill_between(centers[tail_hi], 1e-4, counts[tail_hi] + 1e-4,
                            alpha=0.4, color=c['v1'])
        ax_ins.set_ylim(1e-3, 20)
        ax_ins.set_xlim(rmin - 0.1, rmax + 0.1)
        ax_ins.set_title('Log density', fontsize=7)
        ax_ins.tick_params(labelsize=6)

    ax.set_xlabel('Residual $r(z)$', fontsize=FONT_LABEL)
    ax.set_ylabel('Density', fontsize=FONT_LABEL)
    ax.set_title('(b) Residual distribution (banana $D = 10$)',
                 fontsize=FONT_TITLE, fontweight='bold')
    ax.legend(fontsize=FONT_LEGEND, loc='center left')
    ax.set_xlim(rmin - 0.2, rmax + 0.5)
    ax.set_ylim(bottom=-0.6)


def panel_c_ess(ax):
    """Panel C: ESS proxy vs observed ESS."""
    c = COLORS
    e = ESS_CALIBRATION

    ax.plot(e['rho'], e['proxy'], 's-', color=c['v2_01'], lw=2, ms=8,
            label='Spectral-gap ESS proxy', zorder=3)
    ax.axhline(e['actual'], color=c['actual'], ls='-', lw=2,
               label='Observed ESS ratio = %.3f' % e['actual'], zorder=2)
    ax.fill_between([0, 0.3], e['actual'] * 0.8, e['actual'] * 1.2,
                    alpha=0.1, color=c['actual'])

    # Highlight point
    hr = e['highlight_rho']
    hp = e['highlight_proxy']
    ax.plot(hr, hp, 'o', color=c['highlight'], ms=12,
            markeredgecolor='black', markeredgewidth=1.5, zorder=5)

    gap_pct = abs(hp - e['actual']) / e['actual'] * 100
    annot_text = (r'$\rho = %.2f$ (fixed)' % hr + '\n'
                  + 'proxy = %.3f' % hp + '\n'
                  + 'observed = %.3f' % e['actual'] + '\n'
                  + '(%.0f%% gap)' % gap_pct)
    ax.annotate(annot_text,
                xy=(hr, hp), xytext=(hr + 0.06, hp - 0.11),
                fontsize=10, color=c['highlight'],
                arrowprops=dict(arrowstyle='->', color=c['highlight'], lw=1.2),
                bbox=dict(boxstyle='round,pad=0.3', facecolor='wheat', alpha=0.8))

    ax.set_xlabel(r'Trimming level $\rho$', fontsize=FONT_LABEL)
    ax.set_ylabel('ESS / $n$', fontsize=FONT_LABEL)
    ax.set_title('(c) Spectral-gap ESS proxy vs. observed ESS '
                 '(LogReg $D = 20$)',
                 fontsize=FONT_TITLE - 1, fontweight='bold')
    ax.legend(fontsize=FONT_LEGEND + 1, loc='upper left')
    ax.set_xlim(-0.01, 0.28)
    ax.set_ylim(-0.02, 0.42)
    ax.grid(True, alpha=0.2)


def panel_d_taxonomy(ax):
    """Panel D: Dual-certificate diagnostic taxonomy."""
    ax.axis('off')
    ax.set_title('(d) Dual-certificate diagnostic taxonomy',
                 fontsize=FONT_TITLE, fontweight='bold')

    n_cats = len(TAXONOMY)
    y_positions = [0.85 - i * 0.25 for i in range(n_cats)]

    # Column headers
    ax.text(0.145, 0.97, 'Category', transform=ax.transAxes,
            fontsize=11, fontweight='bold', ha='center')
    ax.text(0.35, 0.97, 'Certificate status', transform=ax.transAxes,
            fontsize=11, fontweight='bold', ha='left')
    ax.text(0.72, 0.97, 'Examples', transform=ax.transAxes,
            fontsize=11, fontweight='bold', ha='left')

    for cat, y in zip(TAXONOMY, y_positions):
        box = FancyBboxPatch(
            (0.02, y - 0.08), 0.25, 0.16,
            boxstyle="round,pad=0.02",
            facecolor=cat['color'], alpha=0.3,
            edgecolor=cat['color'], linewidth=2,
            transform=ax.transAxes)
        ax.add_patch(box)
        ax.text(0.145, y, cat['label'], transform=ax.transAxes,
                fontsize=11, fontweight='bold', ha='center', va='center')
        ax.text(0.35, y, cat['status'], transform=ax.transAxes,
                fontsize=10, ha='left', va='center', color='#333333')
        ax.text(0.72, y, cat['examples'], transform=ax.transAxes,
                fontsize=10, ha='left', va='center', color='#555555',
                style='italic')


# ══════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════

def make_figure(output='fig1_hero', dpi=200, fmt='both', show_inset=True):
    fig = plt.figure(figsize=FIGSIZE)
    gs = fig.add_gridspec(2, 2, hspace=0.35, wspace=0.3,
                          left=0.08, right=0.95, top=0.93, bottom=0.06)

    panel_a_spectral_gap(fig.add_subplot(gs[0, 0]))
    panel_b_residual(fig.add_subplot(gs[0, 1]), show_inset=show_inset)
    panel_c_ess(fig.add_subplot(gs[1, 0]))
    panel_d_taxonomy(fig.add_subplot(gs[1, 1]))

    if fmt in ('both', 'pdf'):
        fig.savefig('%s.pdf' % output, dpi=dpi, bbox_inches='tight')
        print('Saved: %s.pdf' % output)
    if fmt in ('both', 'png'):
        fig.savefig('%s.png' % output, dpi=dpi, bbox_inches='tight')
        print('Saved: %s.png' % output)
    plt.close(fig)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='CerT-MCMC Hero Figure')
    parser.add_argument('--output', default='fig1_hero',
                        help='Output filename (without extension)')
    parser.add_argument('--dpi', type=int, default=200)
    parser.add_argument('--format', choices=['png', 'pdf', 'both'],
                        default='both')
    parser.add_argument('--no-inset', action='store_true',
                        help='Disable log-density inset in Panel B')
    args = parser.parse_args()

    make_figure(output=args.output, dpi=args.dpi, fmt=args.format,
                show_inset=not args.no_inset)
